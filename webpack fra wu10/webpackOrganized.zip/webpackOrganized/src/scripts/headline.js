export default (function headline() {
    const headline = "Welcome to the webpage"
    document.querySelector("h1").innerText = headline
})() //IIFE

