import "./style.scss"
import "./scripts/headline"
import "./scripts/burgermenu"
import "./images/tacos.png"



